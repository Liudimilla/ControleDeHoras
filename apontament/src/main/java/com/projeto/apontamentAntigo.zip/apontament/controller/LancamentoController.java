package com.projeto.apontament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projeto.apontament.datasource.model.Apontamento;
import com.projeto.apontament.repository.LancamentoRepository;


@RestController
public class LancamentoController {
	
	@Autowired
	private LancamentoRepository lancamentoRepository;
	
	@GetMapping(path = "/api/apontamento")
	public List<Apontamento> buscarApontamentos(){
		return lancamentoRepository.findAll();
	}
		
	
	

}
