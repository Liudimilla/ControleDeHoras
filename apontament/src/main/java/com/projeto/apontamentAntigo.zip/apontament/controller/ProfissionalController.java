package com.projeto.apontament.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.projeto.apontament.datasource.model.Profissional;
import com.projeto.apontament.exception.ProfissionalNotFoundException;
import com.projeto.apontament.resource.model.ProfissionalResource;
import com.projeto.apontament.service.BuscaProfissionalPorIdServiceImpl;
import com.projeto.apontament.service.BuscarProfissionalServiceImpl;
import com.projeto.apontament.service.CadastroProfissionais;

@RestController
@RequestMapping(value = "/api")
public class ProfissionalController {

	@Autowired
	private BuscarProfissionalServiceImpl serviceBuscar;

	@Autowired
	private CadastroProfissionais serviceCadastro;

	@Autowired
	private BuscaProfissionalPorIdServiceImpl serviceBuscarPorId;

//	Buscar dados do BD
//	@GetMapping(path = "/profissional")
//	public List<Profissional>buscarProfissional(){
//		return profissionalRepository.findAll();
//}

	@GetMapping(path = "/profissional")
	public List<Profissional> buscarProfissional() {
		return serviceBuscar.buscarTodosOsProfissionais();

	}

	@GetMapping(path = "/profissional/id/{id}")
	public Profissional buscarProfissionalPorId(@PathVariable(name = "id", required = true) Long id)
			throws ProfissionalNotFoundException {
		return serviceBuscarPorId.buscarPorId(id);

	}
// Salva banco de dados
//	@PostMapping(path = "/profissional/save")
//	public void salvarProfissional(@RequestBody Profissional profissional) {
//		profissionalRepository.save(profissional);
//	}

	@PostMapping(path = "/profissional/save")
	public void salvarProfissional(@RequestBody ProfissionalResource profissional) {
		serviceCadastro.cadastro(profissional);
	}

	@DeleteMapping(path = "/profissional/delete/{id}")
	public void deleteProfissional(@PathVariable(name = "id", required = true) Long id)
			throws ProfissionalNotFoundException {
		serviceBuscarPorId.deletarPorId(id);
	}

}
