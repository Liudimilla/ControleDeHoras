//package com.projeto.apontament.exception;
//
//public class ApontamentoResourceException extends Exception{
//
//	private static final long serialVersionUID = -4764692828552455105L;
//
//	public ApontamentoResourceException() {
//		super();
//		
//	}
//
//	public ApontamentoResourceException(String message, Throwable cause, boolean enableSuppression,
//			boolean writableStackTrace) {
//		super(message, cause, enableSuppression, writableStackTrace);
//		
//	}
//
//	public ApontamentoResourceException(String message, Throwable cause) {
//		super(message, cause);
//		
//	}
//
//	public ApontamentoResourceException(String message) {
//		super(message);
//		
//	}
//
//	public ApontamentoResourceException(Throwable cause) {
//		super(cause);
//		
//	}
//
//	
//	
//	
//
//}
