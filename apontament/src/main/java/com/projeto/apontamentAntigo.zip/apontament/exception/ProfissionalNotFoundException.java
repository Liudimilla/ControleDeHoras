//package com.projeto.apontament.exception;
//
//public class ProfissionalNotFoundException extends Exception {
//
//	
//
//	private static final long serialVersionUID = 7726740482580336678L;
//
//	public ProfissionalNotFoundException() {
//		super();
//		
//	}
//
//	public ProfissionalNotFoundException(String message, Throwable cause, boolean enableSuppression,
//			boolean writableStackTrace) {
//		super(message, cause, enableSuppression, writableStackTrace);
//	
//	}
//
//	public ProfissionalNotFoundException(String message, Throwable cause) {
//		super(message, cause);
//		
//	}
//
//	public ProfissionalNotFoundException(String message) {
//		super(message);
//		
//	}
//
//	public ProfissionalNotFoundException(Throwable cause) {
//		super(cause);
//		
//	}
//	
//	
//}
