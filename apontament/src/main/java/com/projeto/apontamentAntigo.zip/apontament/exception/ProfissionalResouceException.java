//package com.projeto.apontament.exception;
//
//public class ProfissionalResouceException extends Exception{
//
//	
//	private static final long serialVersionUID = 6554145573507866793L;
//
//	public ProfissionalResouceException() {
//		super();
//		
//	}
//
//	public ProfissionalResouceException(String message, Throwable cause, boolean enableSuppression,
//			boolean writableStackTrace) {
//		super(message, cause, enableSuppression, writableStackTrace);
//		
//	}
//
//	public ProfissionalResouceException(String message, Throwable cause) {
//		super(message, cause);
//		
//	}
//
//	public ProfissionalResouceException(String message) {
//		super(message);
//		
//	}
//
//	public ProfissionalResouceException(Throwable cause) {
//		super(cause);
//		
//	}
//
//	
//	
//}
