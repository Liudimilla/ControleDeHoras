package com.projeto.apontament.repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.projeto.apontament.datasource.model.Apontamento;

public interface LancamentoRepository extends JpaRepository<Apontamento, Long >{

}
