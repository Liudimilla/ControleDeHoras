//package com.projeto.apontament.service;
//
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.projeto.apontament.datasource.model.Profissional;
//import com.projeto.apontament.exception.ProfissionalNotFoundException;
//import com.projeto.apontament.repository.ProfissionalRepository;
//
//@Service
//public class BuscaProfissionalPorIdServiceImpl {
//
//	@Autowired
//	private ProfissionalRepository profissionalRepository;
//
//	
//	public Profissional buscarPorId(Long id) throws ProfissionalNotFoundException {
//	Optional<Profissional> optionalProfissional = getOptional(id);
//	
//	Profissional profissional = null;
//	
//	if(!optionalProfissional.isPresent()) {
//		throw new ProfissionalNotFoundException(
//				"Profissional nao encontrado atraves do ID" + id);
//		
//	} else {
//		profissional = optionalProfissional.get();
//	}
//	return profissional;
//}
//
//
//	private Optional<Profissional> getOptional(Long id) {
//		Optional<Profissional> optionalProfissional = profissionalRepository.findById(id);
//		return optionalProfissional;
//	}	
//	
//		
//	public void deletarPorId(Long id) throws ProfissionalNotFoundException {
//		Optional<Profissional> optionalProfissional= getOptional(id);
//		if(!optionalProfissional.isPresent()) {
//			throw new ProfissionalNotFoundException(
//					"Profissional nao encontrado atraves do ID" + id);
//			
//		}
//		profissionalRepository.delete(optionalProfissional.get());
//	}
//	
//}
