package com.projeto.apontament.service;

import java.util.List;



import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.projeto.apontament.datasource.model.Profissional;
import com.projeto.apontament.repository.ProfissionalRepository;

@Service
public class BuscarProfissionalServiceImpl {

	private static final Logger LOG = Logger.getLogger(BuscarProfissionalServiceImpl.class);
	
@Autowired
private ProfissionalRepository profissionalRepository;

public List<Profissional> buscarTodosOsProfissionais(){
	LOG.info("Servico para buscar todos os profissionais sendo executados");
	List<Profissional> listProfissionais = profissionalRepository
			.findAll();
	return listProfissionais;
}

}
