package com.projeto.apontament.service;

//import org.jboss.logging.Logger;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import com.projeto.apontament.datasource.model.Profissional;
//import com.projeto.apontament.exception.ProfissionalResouceException;
import com.projeto.apontament.repository.ProfissionalRepository;
import com.projeto.apontament.resource.model.ProfissionalResource;

@Service
public class CadastroProfissionais {
	
//	private static final Logger LOG = Logger
//			.getLogger(CadastroProfissionais.class);

	@Autowired
	public ProfissionalRepository profissionalRepository;
	
//	@Autowired
//	private ProfissionalConversorServiceImpl service;
	
	public void cadastro(ProfissionalResource profissionalResource) {
		
//		try {
//			Profissional profissional = service
//					.conversor(profissionalResource);
//			profissionalRepository.saveAndFlush(profissional);
//		} catch (ProfissionalResouceException e) {
//			LOG.error("Erro ao salvar o profissional" +e.getMessage(), e);
//			
//		}
		
	}
}
