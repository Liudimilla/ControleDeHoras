//package com.projeto.apontament.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.projeto.apontament.datasource.model.Apontamento;
//import com.projeto.apontament.repository.LancamentoRepository;
//
//
//@Service
//public class LancamentosDeAtividadde {
//	@Autowired
//	private LancamentoRepository lancamentoRepository;
//	
//	public void Lancamento(Apontamento apontamento) {
//		//lancamentoRepository.saveAndFlush(apontamento)
//		lancamentoRepository.saveAndFlush(null);
//	}
//
//}
