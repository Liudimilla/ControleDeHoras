package com.projeto.apontament.service;

import com.projeto.apontament.datasource.model.Profissional;
//import com.projeto.apontament.exception.ProfissionalResouceException;
import com.projeto.apontament.resource.model.ProfissionalResource;

public class ProfissionalConversorServiceImpl {
	public Profissional conversor(
			ProfissionalResource profissionalResource) throws ProfissionalResouceException {
	    
		try {	
			Profissional profissional = new Profissional();
			
			Long id = checkId(
					profissionalResource.getId());
			
			String nome = checkNome(profissionalResource.getNome());
			profissional.setId(id);
			profissional.setNome(nome);
			profissional.setChaveM(profissionalResource.getChaveM());
			return profissional;
			
			
		} 
			//catch (Exception e) {
//			throw new ProfissionalResouceException("Falha ao converter o resource para a entidade, resource: "
//					 + profissionalResource);
//		}
//		
//	}
	
	private Long checkId(String id) {
		return Long.parseLong(id);
	}
	
	private String checkNome(String nome) {
		return String.valueOf(nome);
	}

}
